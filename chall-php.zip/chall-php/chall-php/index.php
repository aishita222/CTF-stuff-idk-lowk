<?php
highlight_file(__FILE__);

$secret = trim(file_get_contents('/run/secrets/challenge_flag'));
$key = md5($secret);

if (!isset($_GET['flag'], $_GET['key'])) {
    exit;
}

$input = (string) $_GET['flag'];
$flag = preg_replace('/SMKN22{/', '', $input);

if (substr($flag, 0, 7) !== substr($secret, 0, 7)) {
    die('die');
}

if ($key != (int) $_GET['key']) {
    die('die');
}

echo $secret;
